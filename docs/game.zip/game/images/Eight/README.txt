Eight sprites

7 expressions
1 pose

---

Free/Commercial use (Creative Commons Attribution-ShareAlike)

Please credit annako if used!