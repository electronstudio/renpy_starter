https://liah0227.itch.io
This is a copyright free sprite that can be used in non-commercial and commercial games. You may copy, modify or share this sprite as you see fit, however you may not credit yourself as the creator of this sprite.
Crediting me in your game is not a requirement but it would make me happy.