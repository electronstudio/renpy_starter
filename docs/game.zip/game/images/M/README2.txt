https://ggsalmon.itch.io/kamiya
Asset license: Creative Commons Attribution v4.0 International
