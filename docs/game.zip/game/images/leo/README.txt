KONETT'S RESOURCES

This sprite is lisences under CC-BY-3.0.

This means that you are free to use it in your projects under the condition that you credit Konett.

You can find more resources at 
http://lemmasoft.renai.us/forums/viewtopic.php?f=52&t=28840